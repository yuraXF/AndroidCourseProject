package com.example.yura.todolist.mvp.view;

import com.arellomobile.mvp.MvpView;
import com.example.yura.todolist.mvp.model.NoteModel;

public interface AddNoteView extends MvpView {
    void addNewNote(NoteModel note);
}
