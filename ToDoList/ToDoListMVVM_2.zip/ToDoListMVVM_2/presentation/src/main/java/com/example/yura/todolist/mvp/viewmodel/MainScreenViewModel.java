package com.example.yura.todolist.mvp.viewmodel;

import com.example.domain.Note;
import com.example.domain.interactor.NoteUseCase;
import com.example.domain.repository.NotesRepository;
import com.example.yura.todolist.mvp.model.NoteModel;

import java.util.List;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModel;

public class MainScreenViewModel extends ViewModel {

    MutableLiveData<List<Note>> notes=new MutableLiveData<>();
    private final NotesRepository notesRepository;
    MutableLiveData<Boolean> dataChanges;
    private NoteUseCase noteUseCase;

    public MainScreenViewModel(NotesRepository notesRepository) {
        this.notesRepository = notesRepository;
        notes.postValue(notesRepository.getNotes());
        dataChanges.postValue(false);
        notes.observeForever(new Observer<List<Note>>() {
            @Override
            public void onChanged(List<Note> notes) {
                dataChanges.postValue(true);
            }
        });
    }

    public void removeNote(String id){
        notesRepository.removeNote(id);
        notes.postValue(notesRepository.getNotes());
    }
}
