package com.example.domain.interactor;

import com.example.domain.Note;

import java.util.ArrayList;

public interface NoteUseCase {
    ArrayList<Note> getNoteList();
    void addNote(Note note);
    void removeNote(String id);
    void editNote(Note note);
}
