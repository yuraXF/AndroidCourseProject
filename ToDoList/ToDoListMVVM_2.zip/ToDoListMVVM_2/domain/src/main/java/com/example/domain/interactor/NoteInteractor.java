package com.example.domain.interactor;

import com.example.domain.Note;
import com.example.domain.repository.NotesRepository;

import java.util.ArrayList;

public class NoteInteractor implements NoteUseCase {

    private NotesRepository notesRepository;

    public NoteInteractor(NotesRepository notesRepository) {
        this.notesRepository = notesRepository;
    }

    @Override
    public ArrayList<Note> getNoteList() {
        return (ArrayList<Note>) notesRepository.getNotes();
    }

    @Override
    public void addNote(Note note) {
        notesRepository.addNote(note);
    }

    @Override
    public void removeNote(String id) {
        notesRepository.removeNote(id);
    }

    @Override
    public void editNote(Note note) {
        notesRepository.editNote(note);
    }

}
