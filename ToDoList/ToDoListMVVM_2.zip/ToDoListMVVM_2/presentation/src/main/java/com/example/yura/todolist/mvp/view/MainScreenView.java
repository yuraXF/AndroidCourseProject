package com.example.yura.todolist.mvp.view;

import com.arellomobile.mvp.MvpView;
import com.example.domain.Note;
import com.example.yura.todolist.mvp.model.NoteModel;

import java.util.ArrayList;
import java.util.List;

public interface MainScreenView extends MvpView {
    void bindNotes(List<NoteModel> notes);
}
