package com.example.yura.todolist.mvp.presenter;

import com.arellomobile.mvp.InjectViewState;
import com.arellomobile.mvp.MvpPresenter;
import com.example.domain.Note;
import com.example.domain.interactor.NoteUseCase;
import com.example.yura.todolist.mvp.model.NoteModel;
import com.example.yura.todolist.mvp.model.mapper.NoteModelDataMapper;
import com.example.yura.todolist.mvp.view.EditScreenView;

@InjectViewState
public class EditScreenPresenter extends MvpPresenter<EditScreenView> {
    private NoteUseCase noteUseCase;

    public EditScreenPresenter(NoteUseCase noteUseCase) {
        this.noteUseCase = noteUseCase;
    }

    public void editNote(NoteModel noteModel){
        Note note=new NoteModelDataMapper().transformFrom(noteModel);
        noteUseCase.editNote(note);
    }
}
