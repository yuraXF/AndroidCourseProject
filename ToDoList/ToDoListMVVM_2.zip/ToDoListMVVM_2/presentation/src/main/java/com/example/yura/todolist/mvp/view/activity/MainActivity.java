package com.example.yura.todolist.mvp.view.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;

import com.example.data.repository.NoteRepositoryImpl;
import com.example.domain.interactor.NoteInteractor;
import com.example.domain.interactor.NoteUseCase;
import com.example.domain.repository.NotesRepository;
import com.example.yura.todolist.mvp.model.NoteModel;
import com.example.yura.todolist.mvp.model.mapper.NoteModelDataMapper;
import com.example.yura.todolist.mvp.presenter.MainScreenPresenter;
import com.example.yura.todolist.mvp.view.MainScreenView;
import com.example.yura.todolist.mvp.view.fragment.AddNewNoteDialogFragment;
import com.example.yura.todolist.mvp.view.component.ExtraTags;
import com.example.yura.todolist.mvp.view.adapter.MyAdapter;
import com.example.yura.todolist.R;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity implements MyAdapter.Callback, MainScreenView, AddNewNoteDialogFragment.Callback {

    RecyclerView recyclerView;
    public static MyAdapter myAdapter;
    LinearLayoutManager llm;
    AddNewNoteDialogFragment addNewNoteDialog;
    private final String TAG_DIALOG="my_dialog";
    NotesRepository notesRepository;
    NoteUseCase noteUseCase;
    MainScreenPresenter mainScreenPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("To Do List");
        setSupportActionBar(toolbar);

        //sharedPreferences=getSharedPreferences("note_list",0);

        //NotesList.initsializeList(sharedPreferences.getString(NotesList.NOTE_LIST,""));
        //NotesList.initsializeList();
        //NotesList.sortNotesList();

        notesRepository=new NoteRepositoryImpl(this);
        noteUseCase=new NoteInteractor(notesRepository);
        mainScreenPresenter=new MainScreenPresenter(noteUseCase,this);

        recyclerView=(RecyclerView)findViewById(R.id.rv_main);
        llm=new LinearLayoutManager(MainActivity.this);
        llm.setOrientation(RecyclerView.VERTICAL);
        myAdapter=new MyAdapter((List<NoteModel>) new NoteModelDataMapper().transformTo(noteUseCase.getNoteList()));
        myAdapter.setCallback(this);
        recyclerView.setLayoutManager(llm);
        recyclerView.setAdapter(myAdapter);

        addNewNoteDialog=new AddNewNoteDialogFragment();
        addNewNoteDialog.setCallback(this);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addNewNoteDialog.show(getSupportFragmentManager(),TAG_DIALOG);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_exit){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void showEditActivity(NoteModel noteModel) {
        Intent intent_edit=new Intent(this,EditNoteActivity.class);
        intent_edit.putExtra(ExtraTags.ID, noteModel.getNoteId());
        intent_edit.putExtra(ExtraTags.TITLE, noteModel.getTitle());
        intent_edit.putExtra(ExtraTags.DESCRIPTION, noteModel.getDescription());
        intent_edit.putExtra(ExtraTags.PRIORITY, noteModel.getPriority());
        startActivity(intent_edit);
    }

    @Override
    public void deleteCurrentNote(NoteModel noteModel) {
        mainScreenPresenter.removeNote(noteModel.getNoteId());
        //showNotesPresenter.bindNotes();
    }

    @Override
    public void bindNotes(List<NoteModel> notes) {
        myAdapter.setArrayListNotes(notes);
    }

    @Override
    protected void onResume() {
        super.onResume();
        mainScreenPresenter.bindNotes();
    }

    @Override
    public void doUpdate() {
        mainScreenPresenter.bindNotes();
    }
}
