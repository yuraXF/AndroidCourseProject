package com.example.yura.todolist.mvp.view.component;

public final class ExtraTags {
    public static String ID="ID";
    public static String TITLE="TITLE";
    public static String DESCRIPTION="DESCRIPTION";
    public static String PRIORITY="PRIORITY";

    private ExtraTags(){}
}
