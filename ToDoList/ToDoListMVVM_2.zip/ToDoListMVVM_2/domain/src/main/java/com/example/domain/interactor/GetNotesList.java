package com.example.domain.interactor;

public class GetNotesList {

}
