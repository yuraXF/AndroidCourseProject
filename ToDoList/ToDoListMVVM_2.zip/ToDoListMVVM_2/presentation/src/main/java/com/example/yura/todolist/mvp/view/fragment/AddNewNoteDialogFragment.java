package com.example.yura.todolist.mvp.view.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import com.example.data.repository.NoteRepositoryImpl;
import com.example.domain.interactor.NoteInteractor;
import com.example.domain.interactor.NoteUseCase;
import com.example.domain.repository.NotesRepository;
import com.example.yura.todolist.PriorityTypeEnum;
import com.example.yura.todolist.R;
import com.example.yura.todolist.mvp.model.NoteModel;
import com.example.yura.todolist.mvp.model.mapper.NoteModelDataMapper;
import com.example.yura.todolist.mvp.presenter.AddNotePresenter;

import java.util.UUID;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class AddNewNoteDialogFragment extends DialogFragment {

    private EditText et_title;
    private EditText et_description;
    private Button btn_add;

    private Callback callback;

    AddNotePresenter addNotePresenter;
    NotesRepository notesRepository;
    NoteUseCase noteUseCase;

    public void setCallback(Callback callback) {
        this.callback = callback;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.dialog_fragment,container);
        notesRepository=new NoteRepositoryImpl(view.getContext());
        noteUseCase=new NoteInteractor(notesRepository);
        addNotePresenter=new AddNotePresenter(noteUseCase);
        view.setMinimumWidth(1000);
        view.setMinimumHeight(1000);
        et_title=view.findViewById(R.id.et_title);
        et_description=view.findViewById(R.id.et_description);
        btn_add=view.findViewById(R.id.btn_fragment_add_note);
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NoteModel noteModel=new NoteModel(UUID.randomUUID().toString());
                noteModel.setTitle(et_title.getText().toString());
                noteModel.setDescription(et_description.getText().toString());
                noteModel.setPriority(PriorityTypeEnum.LOW.ordinal());
                addNotePresenter.addNewNote(noteModel);
                callback.doUpdate();
                et_title.setText("");
                et_description.setText("");
                dismiss();
            }
        });
        return view;
    }

    public interface Callback{
        void doUpdate();
    }
}
