package com.example.yura.todolist.mvp.presenter;

import com.arellomobile.mvp.InjectViewState;
import com.arellomobile.mvp.MvpPresenter;
import com.example.domain.Note;
import com.example.domain.interactor.NoteUseCase;
import com.example.yura.todolist.mvp.model.NoteModel;
import com.example.yura.todolist.mvp.model.mapper.NoteModelDataMapper;
import com.example.yura.todolist.mvp.view.AddNoteView;

@InjectViewState
public class AddNotePresenter extends MvpPresenter<AddNoteView> {

    private NoteUseCase noteUseCase;

    public AddNotePresenter(NoteUseCase noteUseCase) {
        this.noteUseCase = noteUseCase;
    }

    public void addNewNote(NoteModel noteModel){
        Note theNote=new NoteModelDataMapper().transformFrom(noteModel);
        noteUseCase.addNote(theNote);
    }
}
