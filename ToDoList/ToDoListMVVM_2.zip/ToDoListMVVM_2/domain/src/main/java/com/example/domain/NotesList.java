package com.example.domain;

import java.util.ArrayList;

public final class NotesList {

    public static ArrayList<Note> notes;

    //public static final String NOTE_LIST="NOTE_LIST";

    private NotesList() {
    }

    /*public static void initsializeList(){
        notes=new ArrayList<Note>();
        notes.add(new Note(PriorityType.HIGH,"Пойти в магазин","Сходить в магазин и купить себе пару буханок хлеба, колбасы и трусы. Еще после этого сходить в чайную лавку и купить булавку"));
        notes.add(new Note(PriorityType.MIDDLE,"Пойти в кафе","Сходить в магазин и купить себе пару буханок хлеба, колбасы и трусы. Еще после этого сходить в чайную лавку и купить булавку"));
        notes.add(new Note(PriorityType.LOW,"Пойти в сад","Сходить в магазин и купить себе пару буханок хлеба, колбасы и трусы. Еще после этого сходить в чайную лавку и купить булавку"));
    }*/

    /*public static void initsializeList(String notes_string){
        Type itemsListType = new TypeToken<ArrayList<Note>>(){}.getType();
        if (notes_string == "") {
            NotesList.notes = new ArrayList<Note>();
        } else {
            NotesList.notes = new ArrayList<Note>();
            NotesList.notes.clear();
            NotesList.notes = new Gson().fromJson(notes_string, itemsListType);
        }
    }

    public static void sortNotesList(){
        Collections.sort(NotesList.notes, new Comparator<Note>() {
            @Override
            public int compare(Note o1, Note o2) {
                return o1.getPriority()<o2.getPriority()?-1:o1.getPriority()>o2.getPriority()?1:0;
            }
        });
    }*/
}
