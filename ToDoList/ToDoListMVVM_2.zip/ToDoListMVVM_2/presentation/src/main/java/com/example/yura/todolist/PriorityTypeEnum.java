package com.example.yura.todolist;

public enum PriorityTypeEnum {
    HIGH, MIDDLE, LOW;
}
