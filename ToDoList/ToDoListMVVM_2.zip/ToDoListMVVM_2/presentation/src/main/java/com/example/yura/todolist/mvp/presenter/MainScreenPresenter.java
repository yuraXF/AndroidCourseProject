package com.example.yura.todolist.mvp.presenter;

import com.arellomobile.mvp.InjectViewState;
import com.arellomobile.mvp.MvpPresenter;
import com.example.domain.interactor.NoteUseCase;
import com.example.yura.todolist.mvp.model.NoteModel;
import com.example.yura.todolist.mvp.model.mapper.NoteModelDataMapper;
import com.example.yura.todolist.mvp.view.MainScreenView;

import java.util.ArrayList;
import java.util.List;

@InjectViewState
public class MainScreenPresenter extends MvpPresenter<MainScreenView> {

    private NoteUseCase noteUseCase;

    MainScreenView mainScreenView;

    public MainScreenPresenter(NoteUseCase noteUseCase, MainScreenView mainScreenView) {
        this.noteUseCase=noteUseCase;
        this.mainScreenView=mainScreenView;
    }

    public void bindNotes(){
        mainScreenView.bindNotes((List<NoteModel>) new NoteModelDataMapper().transformTo(noteUseCase.getNoteList()));
    }

    public void removeNote(String id){
        noteUseCase.removeNote(id);
        bindNotes();
    }

}
